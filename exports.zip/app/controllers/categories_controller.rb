class CategoriesController < ApplicationController
  def index
  end
end
